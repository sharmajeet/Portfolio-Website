var typeData = new Typed(".role",{
    strings:[
        "Full Stack Developer",
        "Web Developer",
        "UI-UX Designer",
        "Backend Developer",
        "Coder",
    ],
    loop:true,
    typeSpeed:100,
    backSpeed:80,
    backDelay:1000,
});